<!DOCTYPE html>
<html>
	<head>
		<meta charset="utf-8"/>
		<title>Deltagare</title>
		<link rel="stylesheet" type="text/css" href="css/style.css"/>
	</head>
	<body>
		<a href='createpost.html'>Gå med i tävlingen</a>
		<?php
			$link = @mysqli_connect('localhost', 'studentweb', 'turtlelove', 'test');
			
			if(!link)
			{
				die('Could not connect to MySQL!');
			}
			
			$query = "SELECT * FROM winners";
			
			$result = @mysqli_query($link, $query);
			if(!$result)
			{
				//$errorstring = 'could not load posts!' . mysqli_error($result);
				print("<script type='text/javascript'>alert('could not load posts');</script>");
				die();
			}
			
			while ($row = mysqli_fetch_row($result)) { // $row blir FALSE när raderna är slut
				
				$printstring = '<div class="content"><h3 class="heading">' . $row[0] . ' ' . $row[1] . '</h3><p class="email">' . $row[2] . '</p><i class="consent">' . $row[3] . '</i></div>';
				print($printstring);
			}
			
			
			
			
			
		?>
	</body>
</html>