<?php

	
	if($_POST['firstname'] == NULL || $_POST['lastname'] == NULL || $_POST['consent'] == NULL || $_POST['email'] == NULL) {
		print("<script type='text/javascript'>alert('Något gick fel. Kolla så att du inte glömt fylla i något!'); window.location.href= 'createpost.html';</script>");
	}
	else {
		
		$link = @mysqli_connect('localhost', 'studentweb', 'turtlelove', 'test');
		
		$firstname = mysqli_real_escape_string($link, $_POST['firstname']);
		$lastname = mysqli_real_escape_string($link, $_POST['lastname']);
		$email = mysqli_real_escape_string($link, $_POST['email']);
		$consent = mysqli_real_escape_string($link, $_POST['consent']);
		
		$query = "INSERT INTO winners VALUES ('$firstname', '$lastname', '$email', '$consent')";
		
		
		$result = @mysqli_query($link, $query);
		if(! $result)
		{
			$errorstring = 'could not save post!' . mysqli_error($result);
			print("<script type='text/javascript'>alert('$errorstring');</script>");
			die();
		}
		
		
		print("<script type='text/javascript'>alert('Post saved!'); window.location.href= 'blog.php';</script>");
		
	}	
?>